%{
#include <stdio.h>

int characters = 0;
int words = 0;
int blank = 0;
int lines = 0;
%}

ALNUM       [a-zA-Z0-9_]
WORDS       {ALNUM}+
BLANK       [ ]

%%

{WORDS}     { words++; characters += yyleng; }
{BLANK}+    { blank += yyleng; characters += yyleng; }
\n          { lines++; characters++; }
.           { characters++; }

%%

int main(int argc, char *argv[])
{
    if (argc > 1) {
        yyin = fopen(argv[1],"r");
    }
    yylex();

    printf("Characters: %d\n", characters);
    printf("Words: %d\n", words);
    printf("Blank spaces: %d\n", blank);
    printf("Lines: %d\n", lines);

    return 0;
}

int yywrap(void)
{
    return 1;
}