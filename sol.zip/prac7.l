%{
#include <stdio.h>
%}

%%
.* {
    for (int i = yyleng; i > 0;i--){
        for (int j = 0;j < i;j++){
            printf("%c",yytext[j]);
        }
        printf("\n");
    }
}
%%

int main() {
    yylex();
}

int yywrap() {
    return 1;
}