
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%%

start : S '\n' ;

S :
      'a' 'b'
    | 'a' S 'b'
    ;

%%

void yyerror(const char *s)
{
    printf("Invalid String\n");
}

int main()
{
    printf("Enter string:\n");

    if(yyparse() == 0)
        printf("Valid String\n");

    return 0;
}
