
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%token LETTER DIGIT

%%

start : LETTER DIGIT '\n' ;

%%

void yyerror(const char *s)
{
    printf("Invalid Variable\n");
}

int main()
{
    printf("Enter variable:\n");

    if(yyparse() == 0)
        printf("Valid Variable\n");

    return 0;
}
