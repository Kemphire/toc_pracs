
%option noyywrap

%{
#include "y.tab.h"
#include <stdlib.h>
%}

%%

[0-9]+(\.[0-9]+)? {
    yylval.d = atof(yytext);
    return NUM;
}

[ \t]      { }
\n         { return '\n'; }
[+\-*/()]  { return yytext[0]; }
.          { return yytext[0]; }

%%
