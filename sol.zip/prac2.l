%{
#include <stdio.h>

int vowels = 0;
int consonants = 0;
%}

VOWELS [aeiouAEIOU]
CONSONANTS [a-zA-Z]

%%

{VOWELS}          { vowels++;}
{CONSONANTS}      { consonants++;}
.                 {}

%%

int main() {
    yylex();

    printf("Number of Vowels %d\n",vowels);
    printf("Number of Consonants %d\n",consonants);

    return 0;
}

int yywrap(){
    return 1;
}