
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%union {
    double d;
}

%token <d> NUM
%type <d> expr

%left '+' '-'
%left '*' '/'

%%

start : expr '\n' {
    printf("Result = %g\n", $1);
}
;

expr :
      expr '+' expr { $$ = $1 + $3; }
    | expr '-' expr { $$ = $1 - $3; }
    | expr '*' expr { $$ = $1 * $3; }
    | expr '/' expr {
        if($3 == 0) {
            printf("Division by zero error\n");
            YYABORT;
        }
        $$ = $1 / $3;
      }
    | '(' expr ')' { $$ = $2; }
    | NUM          { $$ = $1; }
    ;

%%

void yyerror(const char *s)
{
    printf("Invalid Expression\n");
}

int main()
{
    printf("Enter expression:\n");
    yyparse();
    return 0;
}
