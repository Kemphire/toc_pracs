%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%token NUM
%left '+' '-'
%left '*' '/'
%%
start : expr '\n' ;
expr :
      expr '+' expr
    | expr '-' expr
    | expr '*' expr
    | expr '/' expr
    | '(' expr ')'
    | NUM
    ;
%%
void yyerror(const char *s)
{
    printf("Invalid Expression\n");
}
int main()
{
    printf("Enter expression:\n");

    if(yyparse() == 0)
        printf("Valid Expression\n");

    return 0;
}
