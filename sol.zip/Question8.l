
%option noyywrap

%{
#include <stdio.h>
%}

%%

^[ \t]*[0-9]+([ \t]*[+\-*/][ \t]*[0-9]+)*[ \t]*\n {
    printf("Valid Arithmetic Expression\n");
}

^[^\n]*\n {
    printf("Invalid Arithmetic Expression\n");
}

%%

int main()
{
    printf("Enter an arithmetic expression:\n");
    yylex();
    return 0;
}
