%{
#include <stdio.h>
%}

%%

[a-z] {
    printf("%c",'a' + (yytext[0] - 'a' + 3) % 26);
}

[A-Z] {
    printf("%c",'A' + (yytext[0] - 'A' + 3) % 26);
}
%%

int main() {
    yylex();
}

int yywrap() {
    return 1;
}