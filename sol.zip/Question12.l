
%option noyywrap

%%

[a]     { return 'a'; }
[b]     { return 'b'; }
\n      { return '\n'; }
[ \t]   { }
.       { return yytext[0]; }

%%
