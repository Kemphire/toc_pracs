%{
#include <stdio.h>

char longest[1000];
%}

%%
[a-zA-Z]+ {
    if (yyleng > strlen(longest)) {
        strcpy(longest, yytext);
    }
}

.|\n {}
%%

int main() {
    yylex();

    printf("The longest string %s\n", longest);

    return 0;
}

int yywrap() {
    return 1;
}