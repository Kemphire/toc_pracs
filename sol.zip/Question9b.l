
%option noyywrap

%{
#include "y.tab.h"
%}

%%

[a-z]    { return LETTER; }
[0-9]    { return DIGIT; }
[ \t]    { }
\n       { return '\n'; }
.        { return yytext[0]; }

%%
