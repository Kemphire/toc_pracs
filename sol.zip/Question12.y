
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%%

start : A 'b' '\n' ;

A :
      'a' 'a' 'a' 'a' 'a'
      'a' 'a' 'a' 'a' 'a'
    | A 'a'
    ;

%%

void yyerror(const char *s)
{
    printf("Input is Invalid\n");
}

int main()
{
    printf("Enter string:\n");

    if(yyparse() == 0)
        printf("Input is Valid\n");

    return 0;
}
