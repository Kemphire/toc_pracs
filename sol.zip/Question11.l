
%option noyywrap

%%

[ab]    { return yytext[0]; }
\n      { return '\n'; }
[ \t]   { }
.       { return yytext[0]; }

%%
