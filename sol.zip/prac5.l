
%{
#include <stdio.h>
%}

DIGIT       [0-9]
LETTER      [a-zA-Z_]
KEYWORD     (int|float|then|char|if|else|while|for|return|void)
IDENTIFIER  {LETTER}({LETTER}|{DIGIT})*
INTEGER     {DIGIT}+
FLOAT       {DIGIT}+"."{DIGIT}+
OPERATOR    (==|!=|<=|>=|[+\-*/%=<>])

%%

"//".*              { printf("Comment: %s\n", yytext); }
"/*"([^*]|\*+[^*/])*\*+"/"  { printf("Comment: %s\n", yytext); }

{KEYWORD}           { printf("Keyword: %s\n", yytext); }
{FLOAT}             { printf("Float: %s\n", yytext); }
{INTEGER}           { printf("Integer: %s\n", yytext); }
{IDENTIFIER}        { printf("Identifier: %s\n", yytext); }
{OPERATOR}          { printf("Operator: %s\n", yytext); }

[ \t\n]+            {  }
.                   { printf("Special character: %s\n", yytext); }

%%

int main() {
    yylex();
    return 0;
}

int yywrap() {
    return 1;
}
